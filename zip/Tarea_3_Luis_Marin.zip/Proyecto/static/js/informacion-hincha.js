//Vemos los hipervinculos
const redirigir = () => {
    window.location.href = "/ver-hinchas";
}