function cambiarTamaño(img) {
    img.classList.toggle("ampliadas");
}

//Vemos los hipervinculos
const redirigir = () => {
    window.location.href = "/ver-artesanos";
}